#include "DATA:Shaders/globals.inc"

//Effect to render a poygon with texturing no lighting

sampler2D tex0 : register(s0);
sampler2D tex1 : register(s1);
sampler2D tex2 : register(s2);
sampler2D tex3 : register(s3);
sampler2D tex4 : register(s4);
sampler2D tex5 : register(s5);

struct VS_INPUT
{
	float2	Position	: POSITION;
	float4	Colour	: COLOR0;
	float2	UV		: TEXCOORD0;
	int		Tex		: TEXCOORD1;
};

struct VS_OUTPUT
{
	float4	Position	: POSITION;
	float4	Colour	: COLOR0;
	float2	UV		: TEXCOORD0;
	int		Tex		: TEXCOORD1;
};

VS_OUTPUT VS(const VS_INPUT input)
{
	VS_OUTPUT output;
	matrix mtxWVP = mul(mul(mul(mtxWorld, mtxLocalWorld), mtxView), mtxProject);
	output.Position = mul(float4(input.Position, 0.0, 1.0f) , mtxWVP);
	HalfPixelOffset(output.Position.xy);
	
	output.Colour = input.Colour;
	output.UV = input.UV;	
	output.Tex = input.Tex;
	return output;
}

float4 PS(const VS_OUTPUT input) : COLOR
{
	float4 colour = float4(1,1,1,1);

	if (input.Tex > 5)
	{
		colour = tex2D(tex5, input.UV);
	}
	else if (input.Tex > 4)
	{
		colour = tex2D(tex4, input.UV);
	}
	else if (input.Tex > 3)
	{
		colour = tex2D(tex3, input.UV);
	}
	else if (input.Tex > 2)
	{
		colour = tex2D(tex2, input.UV);
	}
	else if (input.Tex > 1)
	{
		colour = tex2D(tex1, input.UV);
	}
	else
	{
		colour = tex2D(tex0, input.UV);
	}
		
	colour.r *= input.Colour.r;
	colour.g *= input.Colour.g;
	colour.b *= input.Colour.b;
	colour.a *= input.Colour.a;
	
	return colour;
}

	
technique SV3
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SrcAlpha;
		DestBlend = InvSrcAlpha;
		ZEnable = true;
		ZWriteEnable = false;
		CullMode = None;		
		VertexShader = compile vs_1_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}

technique SV2
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SrcAlpha;
		DestBlend = InvSrcAlpha;
		ZEnable = true;
		ZWriteEnable = false;
		CullMode = None;		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}