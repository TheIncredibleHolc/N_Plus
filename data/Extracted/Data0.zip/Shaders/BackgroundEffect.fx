matrix worldViewProj;
texture texDiffuseMap;

sampler DiffuseMapSampler = sampler_state
{
    Texture   = (texDiffuseMap);
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    AddressU  = WRAP;
    AddressV  = WRAP;
};

struct VS_INPUT
{
	float3 v3Position	: POSITION;
	float2 v2UV : TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 v4Position	: POSITION;
	float2 v2UV : TEXCOORD0;
};


VS_OUTPUT VS(const VS_INPUT input)
{
	VS_OUTPUT output;
	output.v4Position = mul(float4(input.v3Position, 1.0f), worldViewProj);
	output.v2UV = input.v2UV;
	return output;
}


float4 PS(const VS_OUTPUT input) : COLOR
{   
//return( float4( 0.974f, 0.974f, 0.9333f, 1.0f ) );

	return tex2D(DiffuseMapSampler, input.v2UV);
}


technique ONE
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SrcAlpha;
		DestBlend = InvSrcAlpha;
		ZEnable = true;
		ZWriteEnable = false;
		CullMode = None;		
		VertexShader = compile vs_1_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}
