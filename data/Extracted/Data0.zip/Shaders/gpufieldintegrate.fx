texture texDiffuseMap;
float ooTexelSize = 1.0 / 128.0;

sampler2D DiffuseMapSampler = sampler_state
{
   Texture = (texDiffuseMap);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MINFILTER = POINT;
   MAGFILTER = POINT;
};

texture texVelocityMap;

sampler2D VelocityMapSampler = sampler_state
{
   Texture = (texVelocityMap);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MINFILTER = POINT;
   MAGFILTER = POINT;
};


struct VS_INPUT 
{
   float4 Position : POSITION0;
};

struct VS_OUTPUT 
{
   float4 Position : POSITION0;
   float2 TexCoord : TEXCOORD0;
};

VS_OUTPUT VS( VS_INPUT Input )
{
   VS_OUTPUT Output;
   Output.Position = Input.Position;
   float2 uv = (Input.Position.xy + float2(1.0,1.0)) * 0.5;
   uv.y = 1.0 - uv.y;
   uv.x += ooTexelSize*0.5;	// Hit the middle of the texel
   uv.y += ooTexelSize*0.5;	// Hit the middle of the texel
   Output.TexCoord = uv;
      
   return( Output );
}

struct PS_INPUT
{
	float2 TexCoord : TEXCOORD0;
};

const float systemdamping = 0.98f;
const float damping = 600.0;
const float dtsqr = 1.0/(60.0*60.0);

float4 PS( PS_INPUT Input ) : COLOR0
{   
	//float2 force = float2(0.0f,0.0f);
	float2 vel = 0.0;
	float2 force = tex2D( VelocityMapSampler, Input.TexCoord );
	
	float4 topcenter	= tex2D( DiffuseMapSampler, Input.TexCoord + float2(      0.0,  ooTexelSize) );
	float4 middleleft	= tex2D( DiffuseMapSampler, Input.TexCoord + float2(-ooTexelSize,  0.0) );
	float4 middlecenter	= tex2D( DiffuseMapSampler, Input.TexCoord + float2(      0.0,  0.0) );
	float4 middleright	= tex2D( DiffuseMapSampler, Input.TexCoord + float2( ooTexelSize,  0.0) );
	float4 bottomcenter	= tex2D( DiffuseMapSampler, Input.TexCoord + float2(      0.0, -ooTexelSize) );
	
	// Integrate:

	float2 upspring = topcenter.xy - middlecenter.xy;
	force += upspring * damping;
	float2 downspring = bottomcenter.xy - middlecenter.xy;
	force += downspring * damping;
	float2 leftspring = middleleft.xy - middlecenter.xy;
	force += leftspring * damping;
	float2 rightspring = middleright.xy - middlecenter.xy;
	force += rightspring * damping;

	// Integrate:	
	float4 newPosAndPrevPos;
	newPosAndPrevPos.zw = middlecenter.xy;	// Previous position
	newPosAndPrevPos.xy = middlecenter.xy + ((middlecenter.xy - middlecenter.zw + vel) * systemdamping) + (force * dtsqr);  // Todo: add forces here
//	newPosAndPrevPos.xy = middlecenter.xy + vel + (force * dtsqr);  // Todo: add forces here
	return newPosAndPrevPos;
}


//--------------------------------------------------------------//
// Technique Section for Default_DirectX_Effect
//--------------------------------------------------------------//

technique ONE
{
	pass P0
	{
		AlphaBlendEnable = false;
		ZEnable = false;
		CullMode = None;
		VertexShader = compile vs_3_0 VS();
		PixelShader = compile ps_3_0 PS();
	}
}

