matrix worldViewProj;

texture texDiffuseMap;
float ooTexelSize = 1.0 / 128.0;

sampler2D DiffuseMapSampler = sampler_state
{
   Texture = (texDiffuseMap);
   ADDRESSU = CLAMP;
   ADDRESSV = CLAMP;
   MINFILTER = POINT;
   MAGFILTER = POINT;
};

texture texVelocityMap;

sampler2D VelocityMapSampler = sampler_state
{
   Texture = (texVelocityMap);
   ADDRESSU = WRAP;
   ADDRESSV = WRAP;
   MINFILTER = LINEAR;
   MAGFILTER = LINEAR;
};


struct VS_INPUT 
{
   float2 TexCoord : TEXCOORD0;
};


struct VS_OUTPUT 
{
   float4 Position : POSITION0;
   float2 TexCoord : TEXCOORD0;
};

VS_OUTPUT VS( VS_INPUT Input )
{
   VS_OUTPUT Output;
   
   float4 uv;
   uv.xy = Input.TexCoord;
   uv.z = 0;
   uv.w = 1;
   float4 particleposition = tex2Dlod( DiffuseMapSampler, uv );
  
   float4 vert;
   vert.xy = particleposition.xy;
//   vert.xy = Input.TexCoord;
   vert.z = 0.0f;
   vert.w = 1.0f;
   
   Output.Position = mul(vert,worldViewProj);
   Output.TexCoord = Input.TexCoord;
      
   return( Output );
}

struct PS_INPUT
{
	float2 TexCoord : TEXCOORD0;
};

float4 PS( PS_INPUT Input ) : COLOR0
{   
	return tex2D( VelocityMapSampler, Input.TexCoord );
}


//--------------------------------------------------------------//
// Technique Section for Default_DirectX_Effect
//--------------------------------------------------------------//
technique ONE
{
	pass P0
	{
		ZWRITEENABLE = FALSE;
		ZEnable = false;
		SrcBlend = SrcAlpha;
		DestBlend = InvSrcAlpha;
		CULLMODE = NONE;
		ALPHABLENDENABLE = FALSE;
		VertexShader = compile vs_3_0 VS();
		PixelShader = compile ps_3_0 PS();
	}
}

