#include "DATA:Shaders/globals.inc"

//Effect to render a solid filled poygon


struct VS_INPUT
{
	float3 v3Position	: POSITION;
	float4 v4Colour	: COLOR;
};

struct VS_OUTPUT
{
	float4 v4Position	: POSITION;
	float4 v4Colour	: COLOR;
};

VS_OUTPUT VS(const VS_INPUT input)
{
	VS_OUTPUT output;
	matrix mtxWVP = mul(mul(mul(mtxWorld, mtxLocalWorld), mtxView), mtxProject);
	output.v4Position = mul(float4(input.v3Position, 1.0f) , mtxWVP);
	HalfPixelOffset(output.v4Position.xy);
	
	output.v4Colour = input.v4Colour;
	return output;
}

float4 PS(const VS_OUTPUT input) : COLOR
{
	return input.v4Colour;
}

	
technique ONE
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SrcAlpha;
		DestBlend = InvSrcAlpha;
		ZEnable = true;
		ZWriteEnable = false;
		CullMode = None;		
		VertexShader = compile vs_1_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}

technique MIKE
{
	pass P0
	{
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}