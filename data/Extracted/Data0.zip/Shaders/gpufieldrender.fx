texture texDiffuseMap;

sampler DiffuseMapSampler = sampler_state
{
    Texture   = (texDiffuseMap);
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    AddressU  = CLAMP;
    AddressV  = CLAMP;
};



struct VS_INPUT
{
	float3 Position	: POSITION;
};

struct VS_OUTPUT
{
	float4 Position	: POSITION;
	float2 TexCoord : TEXCOORD0;
};

struct PS_INPUT
{
	float2 TexCoord : TEXCOORD0;
};


VS_OUTPUT VS( VS_INPUT Input )
{
   VS_OUTPUT Output;
   Output.Position.xyz = Input.Position;
   Output.Position.w = 1.0;
   
   float2 uv = (Input.Position.xy + float2(1.0,1.0)) * 0.5;
   uv.y = 1.0 - uv.y;
   uv.x += 1.0/256.0;	// Hit the middle of the texel
   uv.y += 1.0/256.0;	// Hit the middle of the texel
   Output.TexCoord = uv;
      
   return( Output );
}

float4 PS( PS_INPUT Input ) : COLOR0
{   
	return tex2D( DiffuseMapSampler, Input.TexCoord );
}


//--------------------------------------------------------------//
// Technique Section for Default_DirectX_Effect
//--------------------------------------------------------------//
technique ONE
{
	pass P0
	{
		VertexShader = compile vs_1_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}

