#include "DATA:Shaders/globals.inc"

//Effect to render a poygon with texturing no lighting

sampler DiffuseMapSampler = sampler_state
{
    Texture   = (texDiffuseMap);
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
    AddressU  = WRAP;
    AddressV  = WRAP;
};

struct VS_INPUT
{
	float3 v3Position	: POSITION;
	float2 v2UV1		: TEXCOORD0;
};

struct VS_OUTPUT
{
	float4 v4Position	: POSITION;
	float2 v2UV1		: TEXCOORD0;
};

VS_OUTPUT VS(const VS_INPUT input)
{
	VS_OUTPUT output;
	matrix mtxWVP = mul(mul(mul(mtxWorld, mtxLocalWorld), mtxView), mtxProject);
	output.v4Position = mul(float4(input.v3Position, 1.0f) , mtxWVP);
	HalfPixelOffset(output.v4Position.xy);
	
	output.v2UV1 = input.v2UV1;
	return output;
}

float4 PS(const VS_OUTPUT input) : COLOR
{
	//float4 diffuse = tex2D(DiffuseSampler, input.v2UV1);
	//return Decolorize(diffuse * input.v4Colour);
	//return float4(0.5, 0.5, 0.5, 0.5);
	return tex2D(DiffuseMapSampler, input.v2UV1);
}

	
technique ONE
{
	pass P0
	{
		AlphaBlendEnable = true;
		SrcBlend = SrcAlpha;
		DestBlend = InvSrcAlpha;
		ZEnable = true;
		ZWriteEnable = false;
		CullMode = None;		
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}

technique MIKE
{
	pass P0
	{
		VertexShader = compile vs_2_0 VS();
		PixelShader = compile ps_2_0 PS();
	}
}