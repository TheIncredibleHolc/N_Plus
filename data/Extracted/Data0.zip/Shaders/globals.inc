shared matrix mtxWorld;
shared matrix mtxView;
shared matrix mtxProject;
matrix mtxLocalWorld;

shared texture texDiffuseMap;		//The diffuse colour texture map
shared texture texNormalMap;
shared texture texVelocityMap;
shared texture texPressureMap;
shared texture texDivergenceMap;
shared texture texNoiseMap;

shared float fGrayPercentage = 0.0f;;

shared float4 v4GlobalLightColour;

struct Impulse
{
	float4 colour;
    float2 position;    
    float radius;
};

//THIS VALUE MUST MATCH ITS EQUILIVENT IN GraphicsEngine.cpp (MAX_SMOKE_IMPULSE)
#define MAX_INPULSE_COUNT 10

shared Impulse ImpulseArray[MAX_INPULSE_COUNT];
shared int ImpulseCount;

#define DissipationFactor 0.95
static float2 v2SSDims = float2(1280,720);	//Dimensions of the primary screen space in pixels (1280,720)
shared float2 v2RT0Dims;	//Dimensions of the current Render Target 0 in pixels

shared float fDeltaTime;
shared float fDissipation;
shared float fBCScale;



//////////////////////////////////////////////////////////////////////////////
//Functions

//Perform boundry condition tests for the smoke effect
void BCPush(inout float2 TexCoord, out float BCScale)
{
	float2 InvRTDims = 1/v2RT0Dims;
	BCScale = 1.0f;
	
    if(      TexCoord.x < 0.0f+0.5f*InvRTDims.x )
    {
		BCScale = fBCScale;
		TexCoord.x += InvRTDims.x;
	}
    else if( TexCoord.x > 1.0f-1.5f*InvRTDims.x )
    {
		BCScale = fBCScale;
		TexCoord.x -= InvRTDims.x;
	}
    
    if( TexCoord.y < 0.0f+0.5f*InvRTDims.y )
    {
		BCScale = fBCScale;
		TexCoord.y += InvRTDims.y;
	}
    else if( TexCoord.y > 1.0f-1.5f*InvRTDims.y )
    {
		BCScale = fBCScale;
		TexCoord.y -= InvRTDims.y;
	}
}

void HalfPixelOffset(inout float2 position)
{
	position -= float2(1.0, -1.0)/v2RT0Dims;
}

float4x4 SepiaMatrix = {0.393f,	0.349f,	0.272f,	0,
								0.769f,	0.686f,	0.534f,	0,
								0.189f,	0.168f,	0.131f,	0,
								0.000f,	0.000f,	0.00f,	1};
								
float4x4 GreyMatrix = {	0.300f,	0.300f,	0.300f,	0,
								0.590f,	0.590f,	0.590f,	0,
								0.110f,	0.110f,	0.110f,	0,
								0.000f,	0.000f,	0.000f,	1};

//Convert the passed in colour to a acromatic value
float4 Decolorize(float4 colour)
{
	float4 grey = mul(colour, GreyMatrix);
	float4 sepia = mul(colour, SepiaMatrix);
	
	float4 selected = sepia;
	
	return selected*fGrayPercentage + colour*(1-fGrayPercentage);
}